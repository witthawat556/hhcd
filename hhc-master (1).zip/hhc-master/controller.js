const indexRoute = require('./routes/index');
const loginRoute = require('./routes/login');
const userRoute = require('./routes/user');
const patientRoute = require('./routes/patient');
const profileRoute = require('./routes/profile');



module.exports = function(app){

    const indexPath = '/';
    app.get(indexPath,indexRoute.get);

    const patientPath = '/patient';
    app.get(patientPath, patientRoute.get);
    app.post(patientPath, patientRoute.post);
    app.patch(patientPath, patientRoute.patch);




    const userPath = '/user';
    app.get(userPath, userRoute.get);
    app.post(userPath, userRoute.post);
    app.patch(userPath, userRoute.patch);

    const profilePath = "/profile";
    app.post(profilePath, profileRoute.post);



    const loginPath = '/login';
    const check_loginPath = '/check_login';
    app.get(loginPath, loginRoute.get);
    app.post(check_loginPath, loginRoute.check);



    const logoutPath = '/logout';
    app.get(logoutPath,function(req,res){
        res.cookie('token','');
        res.redirect('/login');
    });
};

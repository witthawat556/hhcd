exports.post = function (req,res) {
    let obj = new Object();
    obj.message = '';
    obj.status = false;
    tokenVerify(hhcFunc.getCookie(req,'token'),function(err,patient){
        if(!hhcFunc.isEmpty(patient)){
            pool.getConnection(function(err,connection){
                if (err) {
                    res.json({"code" : 100, "status" : "Error in connection database"});
                    return;
                }

                connection.query( "SELECT count(1) as num from member m where m.id_card = ?; ", //เลือกตารางที่ใช้ในการ Check ID_CARD
                    [ req.body.id_card ] , function(err, rows, fields) {
                        if(!err) {
                            if(rows[0].num >0){
                                obj.message = 'มี ID_CARD นี้แล้ว';
                                res.json(obj);
                                return;
                            }else{
                                connection.query( "INSERT INTO member (id_card) values ( ? )", //เลือกตารางที่ใช้ในการ Check ID_CARD
                                    [ req.body.id_card ] , function(err, rows, fields) {
                                        if(!err) {
                                            obj.data = rows;
                                            obj.status = true
                                            obj.message = "Save Success.";
                                            res.json(obj);
                                            return;
                                        }else {
                                            obj.message = 'Error , please contact admin.';
                                            res.json(obj);
                                            return;
                                        }
                                    });

                                connection.on('error', function(err) {
                                    res.json({"code" : 100, "status" : "Error in connection database"});
                                    return;
                                });
                            }
                        }else {
                            obj.message = 'Error , please contact admin.';
                            res.json(obj);
                            return;
                        }
                    });

                connection.on('error', function(err) {
                    res.json({"code" : 100, "status" : "Error in connection database"});
                    return;
                });
            });
        }else{
            obj.message = "Access Denied.";
            res.json(obj);
            return;
        }
    })
};

const apiRoute = require('./routes/api/api');
module.exports = function(app){
    const version = '1.0.0'
    const path = '/api/'+version;

    app.post(path+'/assetp1', apiRoute.assetp1.save);
}
